The QEMU binary used in this challenge is compiled from https://github.com/espressif/qemu. No modifications have been made to QEMU or the ROMs provided.
The bootloader was built from https://github.com/espressif/esp-idf/tree/v3.1-rc2 with relatively standard configs and secure boot V1 enabled. No modifications have been made to the bootloader.
This is an old version of ESP-IDF, make sure to check for any known vulnerabilities!
You can find the flag in flash.
